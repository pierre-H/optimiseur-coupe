#!/bin/bash


[ -f /usr/local/bin/cutting-optimizer ] && sudo rm -f /usr/local/bin/cutting-optimizer
[ -d /usr/local/bin/help ] && sudo rm -rf /usr/local/bin/help
[ -f /usr/local/bin/uninstall_cutting_optimizer ] && sudo rm -f /usr/local/bin/uninstall_cutting_optimizer
exit 0
